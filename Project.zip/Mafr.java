package fdd;
import java.awt.*;
import javax.swing.*;
import java.io.*;
import java.awt.event.*;
class FFF extends JFrame{
	JPanel PN1=new JPanel();
	JPanel PN2=new JPanel();
	JPanel PN3=new JPanel();
	JPanel PN4=new JPanel();
	JTextField tf1 = new JTextField(6);
	JTextField tf2 = new JTextField(6);
	JTextField tf3 = new JTextField(6);
	JTextField tf4 = new JTextField(6);
	JTextField t1 = new JTextField(6);
	JTextField t2 = new JTextField(6);
	JTextField t3 = new JTextField(6);
	JTextField t4 = new JTextField(6);
	JLabel JL1 = new JLabel("����");
	JLabel JL2 = new JLabel("��");
	JLabel JL3 = new JLabel("����");
	JLabel JL4 = new JLabel("��¥");
	JLabel E;
	
	public FFF(String k) {
	PN1.setBackground(Color.gray);
	setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	Container ContentPane = getContentPane();
	JButton SS = new JButton("����");
	JButton CL = new JButton("����");
	E = new JLabel(k);
	SS.addActionListener(new save());
	CL.addActionListener(new close());
	t1.setEditable(false);
	t2.setEditable(false);
	t3.setEditable(false);
	t4.setEditable(false);
	PN2.setLayout(new GridLayout(0, 3,5,5));
	try {
		FileReader fr = new FileReader(k+".txt");
		 BufferedReader br=new BufferedReader(fr);
         String str=null; 
         int a =1;
         while((str=br.readLine())!=null){
        	 System.out.println(str); 
            switch(a) {
            case 1: t1.setText(str);  a++; break;
            case 2: t2.setText(str);  a++; break;
            case 3: t3.setText(str);  a++; break;
            case 4: t4.setText(str);  a++; break;
         }
	}
         br.close();
	}catch(Exception n) {
		 System.out.println(n);
	}
	for(int i=1; i<13; i++) { 
		switch(i)
		{
			case 1 : PN2.add(JL1); break;
			case 2 : PN2.add(tf1);break;
			case 3 : PN2.add(t1);break;
			case 4 : PN2.add(JL2);break;
			case 5 : PN2.add(tf2); break;
			case 6 : PN2.add(t2);break;
			case 7 : PN2.add(JL3);break;
			case 8 : PN2.add(tf3);break;
			case 9 : PN2.add(t3);break;
			case 10 : PN2.add(JL4);break;
			case 11: PN2.add(tf4);break;
			case 12: PN2.add(t4);break;
		}
	}
	PN1.add(E);
	PN3.add(SS);
	PN3.add(CL);
	setSize(400,350);
	PN4.setLayout(new BorderLayout());
	PN4.add(PN1,BorderLayout.NORTH);
	PN4.add(PN2,BorderLayout.CENTER);
	PN4.add(PN3,BorderLayout.SOUTH);
	add(PN4);
	setVisible(true);
	}
	class save implements ActionListener{
		
		public void actionPerformed(ActionEvent e){
				try {
				FileWriter fw = new FileWriter(E.getText()+".txt");
				BufferedWriter bf = new BufferedWriter(fw);
				t1.setText(tf1.getText());
				t2.setText(tf2.getText());
				t3.setText(tf3.getText());
				t4.setText(tf4.getText());
				bf.write(tf1.getText()+"\r\n");
				bf.write(tf2.getText()+"\r\n");
				bf.write(tf3.getText()+"\r\n");
				bf.write(tf4.getText()+"\r\n");
				bf.close();
			}catch(Exception n) {
				System.out.println(n);
			}
			}
		}
	
	class close implements ActionListener{
		public void actionPerformed(ActionEvent e){
			setVisible(false);
		}
	}
}
public class Mafr extends JFrame{
	private JButton b1,b2,b3,b4,b5,b6,b7,b8,b9;
	class close1 implements ActionListener{
		public void actionPerformed(ActionEvent e){
			setVisible(false);
		}
	}
	class react1 implements ActionListener{
		public void actionPerformed(ActionEvent e) {
			FFF x = new FFF("1");
			}
	}
	class react2 implements ActionListener{
		public void actionPerformed(ActionEvent e) {
			FFF x = new FFF("2");
			}
	}
	class react3 implements ActionListener{
		public void actionPerformed(ActionEvent e) {
			FFF x = new FFF("3");
			}
	}
	class react4 implements ActionListener{
		public void actionPerformed(ActionEvent e) {
			FFF x = new FFF("4");
			}
	}
	class react5 implements ActionListener{
		public void actionPerformed(ActionEvent e) {
			FFF x = new FFF("5");
			}
	}
	class react6 implements ActionListener{
		public void actionPerformed(ActionEvent e) {
			FFF x = new FFF("6");
			}
	}
	class react7 implements ActionListener{
		public void actionPerformed(ActionEvent e) {
			FFF x = new FFF("7");
			}
	}
	class react8 implements ActionListener{
		public void actionPerformed(ActionEvent e) {
			FFF x = new FFF("8");
			}
	}
	class react9 implements ActionListener{
		public void actionPerformed(ActionEvent e) {
			FFF x = new FFF("9");
			}
	}
	public Mafr()
	{
		JPanel P1 = new JPanel();
		JPanel P2 = new JPanel();
		JPanel P3 = new JPanel();
		JPanel P4 = new JPanel();
		P1.setBackground(Color.gray);
		JLabel L1 = new JLabel("����Ʈ �����");
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		Container ContentPane = getContentPane(); 
		
		P2.setLayout(new GridLayout(0, 3,5,5)); 

		for(int i=0; i<9; i++) { // 10���� ��ư ����
			String text = Integer.toString(i+1);
			switch(i+1) {
			case 1: JButton b1 = new JButton(text);
			b1.addActionListener(new react1());
			P2.add(b1); break;
			case 2:JButton b2 = new JButton(text);
			b2.addActionListener(new react2());
			P2.add(b2); break;
			case 3:JButton b3 = new JButton(text);
			b3.addActionListener(new react3());
			P2.add(b3); break;
			case 4:JButton b4 = new JButton(text);
			b4.addActionListener(new react4());
			P2.add(b4); break;
			case 5:JButton b5 = new JButton(text);
			b5.addActionListener(new react5());
			P2.add(b5); break;
			case 6:JButton b6 = new JButton(text);
			b6.addActionListener(new react6());
			P2.add(b6); break;
			case 7:JButton b7 = new JButton(text);
			b7.addActionListener(new react7());
			P2.add(b7); break;
			case 8:JButton b8 = new JButton(text);
			b8.addActionListener(new react8());
			P2.add(b8); break;
			case 9:JButton b9 = new JButton(text);
			b9.addActionListener(new react9());
			P2.add(b9); break;
			}
		}
		JButton B1 = new JButton("����");
		B1.addActionListener(new close1());
		P1.add(L1);
		P3.add(B1);
		P4.setLayout(new BorderLayout());
		P4.add(P1,BorderLayout.NORTH);
		P4.add(P2,BorderLayout.CENTER);
		P4.add(P3,BorderLayout.SOUTH);
		add(P4);
		setTitle("����Ʈ �����");
		setSize(400,350);
		setVisible(true);
	}
	public static void main(String[] args){
		Mafr a = new Mafr();
	}
}
